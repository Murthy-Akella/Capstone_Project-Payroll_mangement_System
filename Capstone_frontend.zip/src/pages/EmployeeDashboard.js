import React from "react";
import { Link, Routes, Route } from "react-router-dom";
import Profile from "./Profile";
import LeaveRequests from "./LeaveRequests";

function EmployeeDashboard() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-3 bg-primary text-white min-vh-100 p-3">
          <h4>Employee Panel</h4>
          <ul className="nav flex-column">
            <li><Link className="nav-link text-white" to="profile">Profile</Link></li>
            <li><Link className="nav-link text-white" to="leaves">Leave Requests</Link></li>
          </ul>
        </div>
        <div className="col-9 p-4">
          <Routes>
            <Route path="profile" element={<Profile />} />
            <Route path="leaves" element={<LeaveRequests />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}
export default EmployeeDashboard;