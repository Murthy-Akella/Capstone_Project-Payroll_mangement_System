// import React, { useEffect, useState } from "react";
// import API from "../api/axios";
// import "./Employees.css";

// function Employees() {
//   const [employees, setEmployees] = useState([]);
//   const [newEmployee, setNewEmployee] = useState({
//     firstName: "",
//     lastName: "",
//     designation: "",
//     phone: "",
//     address: "",
//     baseSalary: "",
//     departmentId: "",
//     jobId: ""
//   });

//   // Fetch employees
//   const fetchEmployees = async () => {
//     try {
//       const res = await API.get("/employees");
//       setEmployees(res.data);
//     } catch (err) {
//       console.error("Error fetching employees:", err);
//     }
//   };

//   useEffect(() => {
//     fetchEmployees();
//   }, []);

//   // Add employee
//  // Add employee
// const addEmployee = async (e) => {
//   e.preventDefault();
//   try {
//     const res = await API.post("/employees", newEmployee); // save in DB
//     setEmployees([...employees, res.data]); // add returned row to table
//     setNewEmployee({
//       firstName: "",
//       lastName: "",
//       designation: "",
//       phone: "",
//       address: "",
//       baseSalary: "",
//       departmentId: "",
//       jobId: ""
//     });
//   } catch (err) {
//     console.error("Error adding employee:", err);
//   }
// };


//   // Delete employee
//   const deleteEmployee = async (id) => {
//   try {
//     await API.delete(`/employees/${id}`);  // delete from DB
//     setEmployees(employees.filter(emp => emp.id !== id)); // update table
//   } catch (err) {
//     console.error("Error deleting employee:", err);
//   }
// };


//   return (
//     <div className="container mt-4">
//       <h2>Employees</h2>

//       {/* Employee Form */}
//       <form className="employee-form" onSubmit={addEmployee}>
//         <input type="text" placeholder="First Name" value={newEmployee.firstName}
//           onChange={(e) => setNewEmployee({ ...newEmployee, firstName: e.target.value })} required />
//         <input type="text" placeholder="Last Name" value={newEmployee.lastName}
//           onChange={(e) => setNewEmployee({ ...newEmployee, lastName: e.target.value })} required />
//         <input type="text" placeholder="Designation" value={newEmployee.designation}
//           onChange={(e) => setNewEmployee({ ...newEmployee, designation: e.target.value })} required />
//         <input type="text" placeholder="Phone" value={newEmployee.phone}
//           onChange={(e) => setNewEmployee({ ...newEmployee, phone: e.target.value })} />
//         <input type="text" placeholder="Address" value={newEmployee.address}
//           onChange={(e) => setNewEmployee({ ...newEmployee, address: e.target.value })} />
//         <input type="number" placeholder="Base Salary" value={newEmployee.baseSalary}
//           onChange={(e) => setNewEmployee({ ...newEmployee, baseSalary: e.target.value })} />
//         <input type="text" placeholder="Department ID" value={newEmployee.departmentId}
//           onChange={(e) => setNewEmployee({ ...newEmployee, departmentId: e.target.value })} />
//         <input type="text" placeholder="Job ID" value={newEmployee.jobId}
//           onChange={(e) => setNewEmployee({ ...newEmployee, jobId: e.target.value })} />

//         <button type="submit" className="btn btn-success">Add</button>
//       </form>

//       {/* Employee Table */}
//       <table className="employee-table mt-3">
//         <thead>
//           <tr>
//             <th>ID</th><th>Name</th><th>Designation</th>
//             <th>Department</th><th>Job</th><th>Salary</th>
//             <th>Phone</th><th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {employees.map((emp) => (
//             <tr key={emp.id}>
//               <td>{emp.id}</td>
//               <td>{emp.firstName} {emp.lastName}</td>
//               <td>{emp.designation}</td>
//               <td>{emp.departmentName || "N/A"}</td>
//               <td>{emp.jobTitle || "N/A"}</td>
//               <td>{emp.baseSalary || 0}</td>
//               <td>{emp.phone}</td>
//               <td>
//                 <button className="btn btn-danger btn-sm"
//                   onClick={() => deleteEmployee(emp.id)}>Delete</button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

// export default Employees;
import React, { useEffect, useState } from "react";
import API from "../api/axios";
import "./Employees.css";

function Employees() {
  const [employees, setEmployees] = useState([]);
  const [newEmployee, setNewEmployee] = useState({
    firstName: "",
    lastName: "",
    designation: "",
    phone: "",
    address: "",
    baseSalary: ""
  });

  // Fetch employees
  const fetchEmployees = async () => {
    try {
      const res = await API.get("/employees");
      setEmployees(res.data);
    } catch (err) {
      console.error("Error fetching employees:", err);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  // Add employee
  const addEmployee = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("/employees", newEmployee); // save in DB
      setEmployees([...employees, res.data]); // add returned row to table
      setNewEmployee({
        firstName: "",
        lastName: "",
        designation: "",
        phone: "",
        address: "",
        baseSalary: ""
      });
    } catch (err) {
      console.error("Error adding employee:", err);
    }
  };

  // Delete employee
  const deleteEmployee = async (id) => {
    try {
      await API.delete(`/employees/${id}`); // delete from DB
      setEmployees(employees.filter((emp) => emp.id !== id)); // update table
    } catch (err) {
      console.error("Error deleting employee:", err);
    }
  };

  return (
    <div className="container mt-4">
      <h2>Employees</h2>

      {/* Employee Form */}
      <form className="employee-form" onSubmit={addEmployee}>
        <input
          type="text"
          placeholder="First Name"
          value={newEmployee.firstName}
          onChange={(e) =>
            setNewEmployee({ ...newEmployee, firstName: e.target.value })
          }
          required
        />
        <input
          type="text"
          placeholder="Last Name"
          value={newEmployee.lastName}
          onChange={(e) =>
            setNewEmployee({ ...newEmployee, lastName: e.target.value })
          }
          required
        />
        <input
          type="text"
          placeholder="Designation"
          value={newEmployee.designation}
          onChange={(e) =>
            setNewEmployee({ ...newEmployee, designation: e.target.value })
          }
          required
        />
        <input
          type="text"
          placeholder="Phone"
          value={newEmployee.phone}
          onChange={(e) =>
            setNewEmployee({ ...newEmployee, phone: e.target.value })
          }
        />
        <input
          type="text"
          placeholder="Address"
          value={newEmployee.address}
          onChange={(e) =>
            setNewEmployee({ ...newEmployee, address: e.target.value })
          }
        />
        <input
          type="number"
          placeholder="Base Salary"
          value={newEmployee.baseSalary}
          onChange={(e) =>
            setNewEmployee({ ...newEmployee, baseSalary: e.target.value })
          }
        />

        <button type="submit" className="btn btn-success">
          Add
        </button>
      </form>

      {/* Employee Table */}
      <table className="employee-table mt-3">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Designation</th>
            <th>Salary</th>
            <th>Phone</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id}>
              <td>{emp.id}</td>
              <td>
                {emp.firstName} {emp.lastName}
              </td>
              <td>{emp.designation}</td>
              <td>{emp.baseSalary || 0}</td>
              <td>{emp.phone}</td>
              <td>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => deleteEmployee(emp.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Employees;
