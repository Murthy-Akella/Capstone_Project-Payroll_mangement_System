import React, { useEffect, useState } from "react";
import API from "../api/axios";

function LeaveRequests() {
  const [leaves, setLeaves] = useState([]);

  // Fetch leave requests on page load
  useEffect(() => {
    const fetchLeaves = async () => {
      try {
        const res = await API.get("/leave");
        setLeaves(res.data);
      } catch (err) {
        console.error("Error fetching leaves:", err);
      }
    };
    fetchLeaves();
  }, []);

  const approveLeave = async (id) => {
    try {
      await API.post(`/leave/${id}/approve`);
      setLeaves(
        leaves.map((l) =>
          l.id === id ? { ...l, status: "APPROVED" } : l
        )
      );
    } catch (err) {
      console.error("Error approving leave:", err);
    }
  };

  const rejectLeave = async (id) => {
    try {
      await API.post(`/leave/${id}/reject`);
      setLeaves(
        leaves.map((l) =>
          l.id === id ? { ...l, status: "REJECTED" } : l
        )
      );
    } catch (err) {
      console.error("Error rejecting leave:", err);
    }
  };

  return (
    <div className="container mt-4">
      <h2>Leave Requests</h2>
      <table className="table table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Employee</th>
            <th>Type</th>
            <th>Period</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {leaves.map((leave) => (
            <tr key={leave.id}>
              <td>{leave.id}</td>
              <td>{leave.employeeName || "N/A"}</td>
              <td>{leave.type || "N/A"}</td>
              <td>{leave.fromDate} → {leave.toDate}</td>
              <td>{leave.status}</td>
              <td>
                <button
                  className="btn btn-success btn-sm me-2"
                  onClick={() => approveLeave(leave.id)}
                >
                  Approve
                </button>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => rejectLeave(leave.id)}
                >
                  Reject
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default LeaveRequests;
