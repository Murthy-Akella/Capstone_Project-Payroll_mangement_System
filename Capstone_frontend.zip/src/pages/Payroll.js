import React, { useEffect, useState } from "react";
import API from "../api/axios";

function Payroll() {
  const [runs, setRuns] = useState([]);
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);

  // Fetch payroll runs on load
  useEffect(() => {
    const fetchRuns = async () => {
      try {
        const res = await API.get("/payroll/runs");
        setRuns(res.data);
      } catch (err) {
        console.error("Error fetching payroll runs:", err);
      }
    };
    fetchRuns();
  }, []);

  const createRun = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post("/payroll/runs", { year, month });
      setRuns([...runs, res.data]); // add run to table
    } catch (err) {
      console.error("Error creating payroll run:", err);
    }
  };

  return (
    <div className="container mt-4">
      <h2>Payroll Runs</h2>
      <form className="d-flex mb-3" onSubmit={createRun}>
        <input
          type="number"
          className="form-control me-2"
          placeholder="Year"
          value={year}
          onChange={(e) => setYear(e.target.value)}
          required
        />
        <input
          type="number"
          className="form-control me-2"
          placeholder="Month"
          value={month}
          onChange={(e) => setMonth(e.target.value)}
          required
        />
        <button type="submit" className="btn btn-primary">Create Run</button>
      </form>

      <table className="table table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Year</th>
            <th>Month</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {runs.map((run) => (
            <tr key={run.id}>
              <td>{run.id}</td>
              <td>{run.year}</td>
              <td>{run.month}</td>
              <td>{run.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Payroll;
