import React, { useEffect, useState } from "react";
import API from "../api/axios";

function Profile() {
  const [profile, setProfile] = useState({});

  const fetchProfile = async () => {
    try {
      const res = await API.get("/users/me");
      setProfile(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { fetchProfile(); }, []);

  const handleChange = (e) => setProfile({ ...profile, [e.target.name]: e.target.value });

  const handleUpdate = async () => {
    await API.put(`/employees/${profile.id}`, profile);
    alert("Profile updated!");
  };

  return (
    <div>
      <h3>My Profile</h3>
      <div className="card p-3">
        <div className="mb-2">
          <label>Name</label>
          <input className="form-control" name="name"
            value={profile.name || ""} onChange={handleChange} />
        </div>
        <div className="mb-2">
          <label>Email</label>
          <input className="form-control" name="email"
            value={profile.email || ""} onChange={handleChange} />
        </div>
        <div className="mb-2">
          <label>Phone</label>
          <input className="form-control" name="phone"
            value={profile.phone || ""} onChange={handleChange} />
        </div>
        <button className="btn btn-primary" onClick={handleUpdate}>Update</button>
      </div>
    </div>
  );
}

export default Profile;
