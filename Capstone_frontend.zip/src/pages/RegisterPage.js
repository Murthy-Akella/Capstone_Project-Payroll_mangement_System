import React from 'react';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Container, Card, Button } from 'react-bootstrap';

const RegisterSchema = Yup.object().shape({
  username: Yup.string().required('Required'),
  email: Yup.string().email('Invalid email').required('Required'),
  password: Yup.string().required('Required'),
  role: Yup.string().required('Required')
});

function RegisterPage() {
  const navigate = useNavigate();

  return (
    <Container className="d-flex justify-content-center align-items-center vh-100">
      <Card className="p-4 shadow-lg w-50">
        <h2 className="mb-4 text-center">Register</h2>
        <Formik
          initialValues={{ username: '', email: '', password: '', role: 'EMPLOYEE' }}
          validationSchema={RegisterSchema}
          onSubmit={async (values, { setSubmitting }) => {
            try {
              await axios.post('/api/v1/users', values, {
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
              });
              alert('User registered successfully');
              navigate('/login');
            } catch (error) {
              alert('Registration failed');
            } finally {
              setSubmitting(false);
            }
          }}
        >
          {({ errors, touched }) => (
            <Form>
              <div className="mb-3">
                <label>Username</label>
                <Field name="username" className="form-control" />
                {errors.username && touched.username ? <div className="text-danger">{errors.username}</div> : null}
              </div>
              <div className="mb-3">
                <label>Email</label>
                <Field name="email" type="email" className="form-control" />
                {errors.email && touched.email ? <div className="text-danger">{errors.email}</div> : null}
              </div>
              <div className="mb-3">
                <label>Password</label>
                <Field name="password" type="password" className="form-control" />
                {errors.password && touched.password ? <div className="text-danger">{errors.password}</div> : null}
              </div>
              <div className="mb-3">
                <label>Role</label>
                <Field as="select" name="role" className="form-select">
                  <option value="ADMIN">Admin</option>
                  <option value="EMPLOYEE">Employee</option>
                </Field>
              </div>
              <Button type="submit" className="w-100">Register</Button>
            </Form>
          )}
        </Formik>
      </Card>
    </Container>
  );
}

export default RegisterPage;
