import React, { useState } from 'react';
import axios from 'axios';
import { Container, Card, Button, Table } from 'react-bootstrap';
import AppNavbar from '../components/Navbar';

function ReportsPage() {
  const [report, setReport] = useState(null);

  const fetchPayrollSummary = async () => {
    try {
      const res = await axios.get('/api/v1/reports/payroll-summary', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setReport(res.data);
    } catch (error) {
      alert('Failed to fetch payroll summary');
    }
  };

  const fetchDeptCost = async () => {
    try {
      const res = await axios.get('/api/v1/reports/department-cost', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setReport(res.data);
    } catch (error) {
      alert('Failed to fetch department cost');
    }
  };

  return (
    <>
      <AppNavbar role="ADMIN" />
      <Container className="mt-4">
        <Card className="p-4 shadow-lg">
          <h2>Reports</h2>
          <Button className="me-2" onClick={fetchPayrollSummary}>Payroll Summary</Button>
          <Button onClick={fetchDeptCost}>Department Cost</Button>
          {report && (
            <Table striped bordered hover className="mt-3">
              <tbody>
                {Object.keys(report).map(key => (
                  <tr key={key}>
                    <td>{key}</td>
                    <td>{report[key]}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      </Container>
    </>
  );
}

export default ReportsPage;
