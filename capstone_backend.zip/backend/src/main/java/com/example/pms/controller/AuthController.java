package com.example.pms.controller;

import com.example.pms.dto.LoginRequest;
import com.example.pms.dto.LoginResponse;
import com.example.pms.dto.RegisterRequest;
import com.example.pms.dto.UserSummary;
import com.example.pms.model.Role;
import com.example.pms.model.User;
import com.example.pms.repo.UserRepository;
import com.example.pms.security.JwtService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

  @Autowired private UserRepository userRepo;
  @Autowired private PasswordEncoder passwordEncoder;
  @Autowired private JwtService jwtService;

  @PostMapping("/seed-admin")
  public ResponseEntity<?> seed() {
    if (userRepo.findByUsername("admin").isEmpty()) {
      User u = new User();
      u.setUsername("admin");
      u.setPassword(passwordEncoder.encode("admin123"));
      u.setEmail("admin@example.com");
      u.setRole(Role.ADMIN);
      u.setActive(true);
      userRepo.save(u);
    }
    return ResponseEntity.ok(Map.of("status","ok"));
  }
  @PostMapping("/register")
  public ResponseEntity<?> register(@RequestBody RegisterRequest request) {
      if (UserRepository.existsByUsername(request.getUsername())) {
          return ResponseEntity.badRequest().body("Username already exists!");
      }

      User user = new User();
      user.setUsername(request.getUsername());
      user.setPassword(passwordEncoder.encode(request.getPassword()));
      user.setRole("EMPLOYEE"); // default role

      userRepo.save(user);
      return ResponseEntity.ok("Employee registered successfully!");
  }

  @PostMapping("/login")
  public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest req) {
    User u = userRepo.findByUsername(req.getUsername()).orElse(null);
    if (u == null || !org.springframework.security.crypto.bcrypt.BCrypt.checkpw(req.getPassword(), u.getPassword())) {
      return ResponseEntity.status(401).build();
    }
    String token = jwtService.generateToken(Map.of("role", u.getRole().name()), u.getUsername());
    LoginResponse res = new LoginResponse(token, new UserSummary(u.getUserId(), u.getUsername(), u.getRole().name()));
    return ResponseEntity.ok(res);
  }
}
