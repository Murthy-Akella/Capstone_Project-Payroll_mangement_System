package com.example.pms.controller;

import com.example.pms.model.Department;
import com.example.pms.model.Job;
import com.example.pms.repo.DepartmentRepository;
import com.example.pms.repo.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class DepartmentJobController {
  @Autowired private DepartmentRepository deptRepo;
  @Autowired private JobRepository jobRepo;

  @GetMapping("/departments")
  @PreAuthorize("hasRole('ADMIN')")
  public List<Department> departments() { return deptRepo.findAll(); }

  @PostMapping("/departments")
  @PreAuthorize("hasRole('ADMIN')")
  public Department createDept(@RequestBody Department d) { return deptRepo.save(d); }

  @PutMapping("/departments/{id}")
  @PreAuthorize("hasRole('ADMIN')")
  public Department updDept(@PathVariable Long id, @RequestBody Department d) { d.setId(id); return deptRepo.save(d); }

  @DeleteMapping("/departments/{id}")
  @PreAuthorize("hasRole('ADMIN')")
  public void delDept(@PathVariable Long id) { deptRepo.deleteById(id); }

  @GetMapping("/jobs")
  @PreAuthorize("hasRole('ADMIN')")
  public List<Job> jobs() { return jobRepo.findAll(); }

  @PostMapping("/jobs")
  @PreAuthorize("hasRole('ADMIN')")
  public Job createJob(@RequestBody Job j) { return jobRepo.save(j); }

  @PutMapping("/jobs/{id}")
  @PreAuthorize("hasRole('ADMIN')")
  public Job updJob(@PathVariable Long id, @RequestBody Job j) { j.setId(id); return jobRepo.save(j); }

  @DeleteMapping("/jobs/{id}")
  @PreAuthorize("hasRole('ADMIN')")
  public void delJob(@PathVariable Long id) { jobRepo.deleteById(id); }
}
