package com.example.pms.controller;

import com.example.pms.model.Employee;
import com.example.pms.repo.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController {
  @Autowired private EmployeeRepository employeeRepo;

  @GetMapping
  @PreAuthorize("hasRole('ADMIN')")
  public List<Employee> list() { return employeeRepo.findAll(); }

  @PostMapping
  @PreAuthorize("hasRole('ADMIN')")
  public Employee create(@RequestBody Employee e) { return employeeRepo.save(e); }

  @GetMapping("/{id}")
  public ResponseEntity<Employee> get(@PathVariable Long id) {
    return employeeRepo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
  }

  @PutMapping("/{id}")
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<Employee> update(@PathVariable Long id, @RequestBody Employee e) {
    return employeeRepo.findById(id).map(x -> {
      e.setEmployeeId(id);
      return ResponseEntity.ok(employeeRepo.save(e));
    }).orElse(ResponseEntity.notFound().build());
  }
}
