package com.example.pms.controller;

import com.example.pms.model.LeaveRequest;
import com.example.pms.repo.LeaveRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/leave")
public class LeaveController {
  @Autowired private LeaveRepository leaveRepo;

  @PostMapping("/apply")
  public LeaveRequest apply(@RequestBody LeaveRequest req) {
    req.setStatus("Pending");
    return leaveRepo.save(req);
  }

  @GetMapping
  @PreAuthorize("hasRole('ADMIN')")
  public List<LeaveRequest> list() { return leaveRepo.findAll(); }

  @PostMapping("/{id}/approve")
  @PreAuthorize("hasRole('ADMIN')")
  public LeaveRequest approve(@PathVariable Long id) {
    LeaveRequest lr = leaveRepo.findById(id).orElseThrow();
    lr.setStatus("Approved");
    return leaveRepo.save(lr);
  }

  @PostMapping("/{id}/reject")
  @PreAuthorize("hasRole('ADMIN')")
  public LeaveRequest reject(@PathVariable Long id) {
    LeaveRequest lr = leaveRepo.findById(id).orElseThrow();
    lr.setStatus("Rejected");
    return leaveRepo.save(lr);
  }
}
