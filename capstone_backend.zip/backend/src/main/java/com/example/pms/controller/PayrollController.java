package com.example.pms.controller;

//import com.example.pms.model.Employee;
import com.example.pms.model.Payroll;
import com.example.pms.repo.EmployeeRepository;
import com.example.pms.service.PayrollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/payroll")
public class PayrollController {
  @Autowired private PayrollService payrollService;
  @Autowired private EmployeeRepository employeeRepo;

  @PostMapping("/runs")
  @PreAuthorize("hasRole('ADMIN')")
  public Map<String, Object> createRun(@RequestBody Map<String, Integer> body) {
    int year = body.get("year");
    int month = body.get("month");
    // demo: process all employees
    employeeRepo.findAll().forEach(e -> payrollService.processPayroll(e, year, month));
    return Map.of("status","processed","year",year,"month",month);
  }

  @GetMapping("/my/{year}/{month}")
  public List<Payroll> my(@PathVariable int year, @PathVariable int month, @RequestParam Long employeeId) {
    return payrollService.itemsForRun(employeeId, year, month);
  }
}
