package com.example.pms.controller;

import com.example.pms.model.Role;
import com.example.pms.model.User;
import com.example.pms.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

  @Autowired private UserRepository userRepo;
  @Autowired private PasswordEncoder passwordEncoder;

  @GetMapping("/me")
  public ResponseEntity<?> me(@org.springframework.security.core.annotation.AuthenticationPrincipal org.springframework.security.core.userdetails.User principal) {
    return ResponseEntity.ok(Map.of("username", principal.getUsername()));
  }

  @PostMapping
  @PreAuthorize("hasRole('ADMIN')")
  public User create(@RequestBody Map<String,Object> body) {
    User u = new User();
    u.setUsername((String) body.get("username"));
    u.setPassword(passwordEncoder.encode((String) body.get("password")));
    u.setEmail((String) body.get("email"));
    u.setRole(Role.valueOf(((String)body.get("role")).toUpperCase()));
    u.setActive(true);
    return userRepo.save(u);
  }

  @PatchMapping("/{id}/status")
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<?> status(@PathVariable Long id, @RequestBody Map<String,Boolean> req) {
    return userRepo.findById(id).map(u -> {
      Boolean active = req.getOrDefault("active", Boolean.TRUE);
      u.setActive(active);
      userRepo.save(u);
      return ResponseEntity.ok(Map.of("id", id, "active", u.isActive()));
    }).orElse(ResponseEntity.notFound().build());
  }
}
