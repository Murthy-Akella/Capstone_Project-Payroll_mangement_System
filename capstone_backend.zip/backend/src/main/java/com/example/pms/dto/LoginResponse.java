package com.example.pms.dto;
public class LoginResponse {
  private String accessToken;
  private UserSummary user;
  public LoginResponse() {}
  public LoginResponse(String accessToken, UserSummary user){
    this.accessToken = accessToken; this.user = user;
  }
  public String getAccessToken() { return accessToken; }
  public void setAccessToken(String accessToken) { this.accessToken = accessToken; }
  public UserSummary getUser() { return user; }
  public void setUser(UserSummary user) { this.user = user; }
}
