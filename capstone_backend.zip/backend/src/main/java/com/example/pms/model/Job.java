package com.example.pms.model;

import jakarta.persistence.*;

@Entity
@Table(name="jobs")
public class Job {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String title;
  private Double baseSalary;

  public Job() {}

  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public String getTitle() { return title; }
  public void setTitle(String title) { this.title = title; }
  public Double getBaseSalary() { return baseSalary; }
  public void setBaseSalary(Double baseSalary) { this.baseSalary = baseSalary; }
}
