package com.example.pms.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="leave_requests")
public class LeaveRequest {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long leaveId;

  @ManyToOne @JoinColumn(name="employee_id")
  private Employee employee;

  private LocalDate startDate;
  private LocalDate endDate;
  private String leaveType;
  private String status; // Pending / Approved / Rejected

  public LeaveRequest() {}

  public Long getLeaveId() { return leaveId; }
  public void setLeaveId(Long leaveId) { this.leaveId = leaveId; }
  public Employee getEmployee() { return employee; }
  public void setEmployee(Employee employee) { this.employee = employee; }
  public LocalDate getStartDate() { return startDate; }
  public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
  public LocalDate getEndDate() { return endDate; }
  public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
  public String getLeaveType() { return leaveType; }
  public void setLeaveType(String leaveType) { this.leaveType = leaveType; }
  public String getStatus() { return status; }
  public void setStatus(String status) { this.status = status; }
}
