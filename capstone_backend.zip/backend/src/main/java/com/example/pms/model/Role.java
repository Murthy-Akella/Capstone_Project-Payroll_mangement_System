package com.example.pms.model;
public enum Role { ADMIN, EMPLOYEE }
