package com.example.pms.repo;
import com.example.pms.model.LeaveRequest;
import org.springframework.data.jpa.repository.JpaRepository;
public interface LeaveRepository extends JpaRepository<LeaveRequest, Long> { }
