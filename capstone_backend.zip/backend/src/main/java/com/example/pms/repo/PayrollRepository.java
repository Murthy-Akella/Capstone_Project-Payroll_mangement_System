package com.example.pms.repo;
import com.example.pms.model.Payroll;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface PayrollRepository extends JpaRepository<Payroll, Long> {
  List<Payroll> findByEmployee_EmployeeIdAndYearAndMonth(Long empId, Integer year, Integer month);
}
