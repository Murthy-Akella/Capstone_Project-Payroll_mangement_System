//package com.example.pms.repo;
//import com.example.pms.model.User;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.util.Optional;
//public interface UserRepository extends JpaRepository<User, Long> {
//  Optional<User> findByUsername(String username);
//}
package com.example.pms.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.pms.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    Optional<User> findByUsername(String username);

    static boolean existsByUsername(String username) {
		// TODO Auto-generated method stub
		return false;
	}
}
