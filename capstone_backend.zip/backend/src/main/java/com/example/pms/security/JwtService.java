package com.example.pms.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;
import java.security.Key;
import java.util.Date;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtService {
  private static final String SECRET = "REPLACE_WITH_A_LONG_RANDOM_SECRET_KEY_AT_LEAST_256_BITS________________________________";

  private Key getSignInKey() {
    byte[] keyBytes = Decoders.BASE64.decode(java.util.Base64.getEncoder().encodeToString(SECRET.getBytes()));
    return Keys.hmacShaKeyFor(keyBytes);
  }

  public String generateToken(Map<String, Object> extraClaims, String username) {
    return Jwts.builder()
            .setClaims(extraClaims)
            .setSubject(username)
            .setIssuedAt(new Date(System.currentTimeMillis()))
            .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10))
            .signWith(getSignInKey(), SignatureAlgorithm.HS256)
            .compact();
  }

  public String extractUsername(String token) {
    return extractClaim(token, io.jsonwebtoken.Claims::getSubject);
  }

  public <T> T extractClaim(String token, Function<io.jsonwebtoken.Claims, T> resolver) {
    final io.jsonwebtoken.Claims claims = Jwts.parserBuilder()
            .setSigningKey(getSignInKey()).build()
            .parseClaimsJws(token).getBody();
    return resolver.apply(claims);
  }
}
