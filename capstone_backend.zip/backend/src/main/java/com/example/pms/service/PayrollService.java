package com.example.pms.service;

import com.example.pms.model.Employee;
import com.example.pms.model.Payroll;
import com.example.pms.repo.PayrollRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class PayrollService {
  @Autowired private PayrollRepository payrollRepo;

  public Payroll processPayroll(Employee emp, int year, int month) {
    double basic = emp.getBaseSalary() != null ? emp.getBaseSalary() : 0.0;
    double deductions = basic * 0.1;
    double bonus = basic * 0.05;
    double net = basic - deductions + bonus;

    Payroll p = new Payroll();
    p.setEmployee(emp);
    p.setBasicSalary(basic);
    p.setDeductions(deductions);
    p.setBonus(bonus);
    p.setNetSalary(net);
    p.setPayDate(LocalDate.of(year, month, 28));
    p.setYear(year);
    p.setMonth(month);
    return payrollRepo.save(p);
  }

  public List<Payroll> itemsForRun(Long empId, int year, int month) {
    return payrollRepo.findByEmployee_EmployeeIdAndYearAndMonth(empId, year, month);
  }
}
