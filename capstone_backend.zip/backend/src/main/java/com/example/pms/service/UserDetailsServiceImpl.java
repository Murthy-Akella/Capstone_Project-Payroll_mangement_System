package com.example.pms.service;

import com.example.pms.model.User;
import com.example.pms.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
  @Autowired private UserRepository userRepository;

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    User u = userRepository.findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    return new org.springframework.security.core.userdetails.User(
        u.getUsername(), u.getPassword(),
        //u.isActive(), true, true, true,
        List.of(new SimpleGrantedAuthority("ROLE_" + u.getRole()))
    );
  }
}
// package com.example.pms.service;

// import com.example.pms.model.User;
// import com.example.pms.repo.UserRepository;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.security.core.authority.SimpleGrantedAuthority;
// import org.springframework.security.core.userdetails.UserDetails;
// import org.springframework.security.core.userdetails.UserDetailsService;
// import org.springframework.security.core.userdetails.UsernameNotFoundException;
// import org.springframework.stereotype.Service;

// import java.util.Collections;

// @Service
// public class UserDetailsServiceImpl implements UserDetailsService {

//     @Autowired 
//     private UserRepository userRepository;

//     @Override
//     public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//         User u = userRepository.findByUsername(username)
//                 .orElseThrow(() -> new UsernameNotFoundException("User not found"));

//         // Normalize role (avoid ROLE_ROLE_ADMIN bug)
//         String role = u.getRole().toUpperCase().startsWith("ROLE_")
//                 ? u.getRole().toUpperCase()
//                 : "ROLE_" + u.getRole().toUpperCase();

//         return new org.springframework.security.core.userdetails.User(
//                 u.getUsername(),
//                 u.getPassword(),
//                 u.isActive(),   // enabled
//                 true,           // accountNonExpired
//                 true,           // credentialsNonExpired
//                 true,           // accountNonLocked
//                 Collections.singleton(new SimpleGrantedAuthority(role))
//         );
//     }
// }

